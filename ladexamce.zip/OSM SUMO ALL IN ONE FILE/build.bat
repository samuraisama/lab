@echo off
setlocal
cd /d "%~dp0"
title Rebuild three-class SUMO demand

echo Rebuilding 150 cars, 18 trucks and 2 ambulances...
python build_scenario.py
if errorlevel 1 (
    echo Route generation failed.
    pause
    exit /b 1
)

echo.
echo Routes regenerated. Run run.bat to build the signals and launch SUMO.
pause
endlocal
exit /b 0
