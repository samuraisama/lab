#!/usr/bin/env python3
"""Validate routes against the generated signalised SUMO network."""
from __future__ import annotations
import gzip
import sys
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from pathlib import Path

BASE = Path(__file__).resolve().parent
NET = BASE / "osm.signal.net.xml.gz"
ROUTES = BASE / "emergency.rou.xml"
TARGETS = ("312114070", "312114574")
BUFFER = 40.0


def load_xml(path):
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rb") as stream:
        return ET.parse(stream).getroot()


def main():
    if not NET.is_file():
        raise FileNotFoundError("osm.signal.net.xml.gz is missing. Run build_signal_network.bat first.")
    net = load_xml(NET)
    route_root = load_xml(ROUTES)

    junctions = {j.get("id"): j for j in net.findall("junction")}
    tl_logic_ids = {x.get("id") for x in net.findall("tlLogic")}
    for signal_id in TARGETS:
        if signal_id not in junctions or junctions[signal_id].get("type") != "traffic_light":
            raise RuntimeError(f"Junction {signal_id} is not a traffic_light in osm.signal.net.xml.gz")
        if signal_id not in tl_logic_ids:
            raise RuntimeError(f"Signal program {signal_id} is missing")

    edges = {}
    for edge in net.findall("edge"):
        if edge.get("function") == "internal":
            continue
        lanes = edge.findall("lane")
        if lanes:
            edges[edge.get("id")] = {
                "length": max(float(lane.get("length", "0")) for lane in lanes),
                "lanes": set(range(len(lanes))),
                "from": edge.get("from"),
                "to": edge.get("to"),
            }
    conns = defaultdict(set)
    for conn in net.findall("connection"):
        if conn.get("from") and conn.get("to"):
            conns[(conn.get("from"), conn.get("to"))].add(int(conn.get("fromLane", "0")))

    vehicles = route_root.findall("vehicle")
    if not vehicles:
        raise RuntimeError("No vehicles found in emergency.rou.xml")
    departures = [float(v.get("depart", "-1")) for v in vehicles]
    if departures != sorted(departures):
        raise RuntimeError("Vehicle entries are not sorted by departure time")

    counts = Counter()
    signal_counts = {node: Counter() for node in TARGETS}
    errors = []
    for vehicle in vehicles:
        vehicle_type = vehicle.get("type", "")
        counts[vehicle_type] += 1
        route = vehicle.find("route")
        if route is None:
            errors.append(f"{vehicle.get('id')}: missing route")
            continue
        path = route.get("edges", "").split()
        for edge_id in path:
            if edge_id not in edges:
                errors.append(f"{vehicle.get('id')}: unknown edge {edge_id}")
                break
        for first, second in zip(path, path[1:]):
            allowed_lanes = conns.get((first, second), set())
            if not allowed_lanes:
                errors.append(f"{vehicle.get('id')}: disconnected edges {first} -> {second}")
                continue
            edge = edges[first]
            if len(edge["lanes"]) > 1 and allowed_lanes != edge["lanes"] and edge["length"] < BUFFER:
                errors.append(
                    f"{vehicle.get('id')}: short lane-restricted turn {first} -> {second} ({edge['length']:.2f} m)"
                )
            node = edge["to"]
            if node in TARGETS and node == edges[second]["from"]:
                signal_counts[node][vehicle_type] += 1

    if errors:
        for item in errors[:30]:
            print("ERROR:", item)
        raise RuntimeError(f"Preflight failed with {len(errors)} route problem(s)")

    expected = {"passenger_car": 150, "urban_truck": 18, "ambulance": 2}
    for kind, wanted in expected.items():
        if counts.get(kind, 0) != wanted:
            raise RuntimeError(f"Expected {wanted} {kind} vehicles, found {counts.get(kind, 0)}")

    if signal_counts[TARGETS[0]]["passenger_car"] < 100 or signal_counts[TARGETS[0]]["urban_truck"] < 10:
        raise RuntimeError("Primary signal does not have the required car/truck traffic demand")
    if signal_counts[TARGETS[1]]["passenger_car"] < 25 or signal_counts[TARGETS[1]]["urban_truck"] < 4:
        raise RuntimeError("Secondary signal does not have the required car/truck traffic demand")
    for ambulance in (v for v in vehicles if v.get("type") == "ambulance"):
        path = ambulance.find("route").get("edges", "").split()
        visited = set()
        for a, b in zip(path, path[1:]):
            if a in edges and b in edges and edges[a]["to"] == edges[b]["from"]:
                visited.add(edges[a]["to"])
        if not all(node in visited for node in TARGETS):
            raise RuntimeError(f"{ambulance.get('id')} does not pass both signalised junctions")

    print("PRE-FLIGHT PASSED")
    print(f"  total vehicles: {len(vehicles)}")
    print(f"  passenger cars: {counts['passenger_car']}")
    print(f"  trucks:         {counts['urban_truck']}")
    print(f"  ambulances:     {counts['ambulance']}")
    for node in TARGETS:
        print(
            f"  signal {node}: cars={signal_counts[node]['passenger_car']}, "
            f"trucks={signal_counts[node]['urban_truck']}, "
            f"ambulances={signal_counts[node]['ambulance']}"
        )
    print("  route connectivity: valid")
    print("  short lane-restricted turns: none")
    print("  departure ordering: valid")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
