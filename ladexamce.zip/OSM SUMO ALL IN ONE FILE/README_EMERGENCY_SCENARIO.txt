IMPORTANT: USE THE REAL SIGNALISED SCENARIO GUIDE

The original emergency-only instructions are obsolete.
Read README_REAL_WORLD_SIGNALS.txt and launch the simulation with run.bat.

run.bat builds the signalised network, validates routes, then starts the SUMO-GUI
TraCI controller which grants ambulance-only green at the two signalised
junctions. Do not launch osm.sumocfg directly for emergency pre-emption.
