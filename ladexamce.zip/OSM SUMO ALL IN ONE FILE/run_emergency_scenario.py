#!/usr/bin/env python3
"""Run the signalised mixed-traffic scenario and implement ambulance pre-emption.

Normal vehicles obey the generated static signals.  On an ambulance approach,
this controller changes the current signal to amber, clears the junction with
an all-red interval, grants green only to the ambulance movement, then gives
that movement amber/all-red before restoring the ordinary signal program.
"""
from __future__ import annotations

import os
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "osm.sumocfg"
SIGNAL_NETWORK = BASE_DIR / "osm.signal.net.xml.gz"
ROUTE_FILE = BASE_DIR / "emergency.rou.xml"
TARGET_TLS = {"312114070", "312114574"}
PREEMPTION_TRIGGER_METRES = 120.0
YELLOW_SECONDS = 3.0
ALL_RED_SECONDS = 1.5
POST_EMERGENCY_YELLOW_SECONDS = 3.0
MAX_PREEMPT_WAIT_SECONDS = 30.0
REACTION_DISTANCE_METRES = 60.0
EMERGENCY_PREFIX = "ambulance_"


def find_sumo_home() -> Path:
    configured = os.environ.get("SUMO_HOME")
    if configured:
        home = Path(configured).expanduser().resolve()
        if (home / "tools").is_dir():
            return home

    binary = shutil.which("sumo-gui") or shutil.which("sumo-gui.exe")
    if binary:
        candidate = Path(binary).resolve().parent.parent
        if (candidate / "tools").is_dir():
            return candidate

    candidates = [
        Path(r"C:\Program Files (x86)\Eclipse\Sumo"),
        Path(r"C:\Program Files\Eclipse\Sumo"),
        Path(r"C:\SUMO"),
    ]
    for base_name in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles")):
        if base_name:
            eclipse_dir = Path(base_name) / "Eclipse"
            if eclipse_dir.is_dir():
                candidates.extend(sorted(eclipse_dir.glob("Sumo*")))
    for candidate in candidates:
        if (candidate / "tools").is_dir():
            return candidate
    raise FileNotFoundError(
        "Could not locate SUMO_HOME. Set SUMO_HOME to the SUMO installation folder "
        "(the folder containing bin and tools)."
    )


def lane_to_edge(lane_id: str) -> tuple[str, int]:
    edge_id, lane_text = lane_id.rsplit("_", 1)
    return edge_id, int(lane_text)


@dataclass
class SignalPreemption:
    tls_id: str
    ambulance_id: str
    link_index: int
    incoming_edge: str
    incoming_lane: int
    incoming_lane_id: str
    stop_position: float
    outgoing_edge: str
    saved_program: str
    saved_phase: int
    saved_remaining: float
    stage: str
    stage_until: float


def choose_ambulance_movement(traci, ambulance_id: str, tls_id: str, link_index: int):
    """Return the route-matching incoming/outgoing movement for a TLS link."""
    controlled = traci.trafficlight.getControlledLinks(tls_id)
    if link_index < 0 or link_index >= len(controlled):
        raise RuntimeError(
            f"TLS {tls_id}: link index {link_index} is outside controlled-link list ({len(controlled)} links)"
        )

    route = list(traci.vehicle.getRoute(ambulance_id))
    route_index = max(0, int(traci.vehicle.getRouteIndex(ambulance_id)))
    group = controlled[link_index]
    possible = []
    for movement in group:
        if len(movement) < 2:
            continue
        from_lane, to_lane = movement[0], movement[1]
        if not from_lane or not to_lane:
            continue
        from_edge, lane_index = lane_to_edge(from_lane)
        to_edge, _ = lane_to_edge(to_lane)
        for index in range(route_index, len(route) - 1):
            if route[index] == from_edge and route[index + 1] == to_edge:
                possible.append((from_lane, to_lane, from_edge, lane_index, to_edge))
                break
    if not possible:
        # With ungrouped TLS signals this is normally a single movement.
        # Fall back to the sole link only when it is route-consistent.
        raise RuntimeError(
            f"Could not match ambulance {ambulance_id}'s route to TLS {tls_id}, link {link_index}"
        )
    return possible[0]


def issue_approach_stop(traci, ambulance_id: str, incoming_edge: str,
                        lane_index: int, incoming_lane_id: str) -> float:
    lane_length = float(traci.lane.getLength(incoming_lane_id))
    # Hold the ambulance 7 m before the stop line. The native blue-light
    # device remains active for siren/flashing lights and rescue-lane response,
    # but the explicit stop prevents it entering during yellow/all-red.
    stop_pos = max(1.0, lane_length - 7.0)
    traci.vehicle.setStop(
        ambulance_id,
        incoming_edge,
        stop_pos,
        laneIndex=lane_index,
        duration=3_600_000,
        flags=0,
    )
    return stop_pos


def all_red(length: int) -> str:
    return "r" * length


def amber_for_current_green(state: str) -> str:
    return "".join("y" if char in "gGyY" else "r" for char in state)


def set_signal_state(traci, tls_id: str, state: str) -> None:
    traci.trafficlight.setRedYellowGreenState(tls_id, state)


def begin_preemption(traci, tls_id: str, ambulance_id: str, link_index: int,
                     now: float) -> SignalPreemption:
    from_lane, to_lane, incoming_edge, lane_index, outgoing_edge = choose_ambulance_movement(
        traci, ambulance_id, tls_id, link_index
    )
    stop_pos = issue_approach_stop(
        traci, ambulance_id, incoming_edge, lane_index, from_lane
    )

    original_state = traci.trafficlight.getRedYellowGreenState(tls_id)
    saved_program = traci.trafficlight.getProgram(tls_id)
    saved_phase = int(traci.trafficlight.getPhase(tls_id))
    saved_remaining = max(1.0, float(traci.trafficlight.getNextSwitch(tls_id)) - now)

    yellow_state = amber_for_current_green(original_state)
    if "y" in yellow_state:
        set_signal_state(traci, tls_id, yellow_state)
        stage = "yellow_before_preemption"
        stage_until = now + YELLOW_SECONDS
    else:
        set_signal_state(traci, tls_id, all_red(len(original_state)))
        stage = "all_red_before_preemption"
        stage_until = now + ALL_RED_SECONDS

    print(
        f"[{now:7.1f}s] AMBULANCE {ambulance_id} requests priority at {tls_id}; "
        f"current green -> amber, then all-red."
    )
    return SignalPreemption(
        tls_id=tls_id,
        ambulance_id=ambulance_id,
        link_index=link_index,
        incoming_edge=incoming_edge,
        incoming_lane=lane_index,
        incoming_lane_id=from_lane,
        stop_position=stop_pos,
        outgoing_edge=outgoing_edge,
        saved_program=saved_program,
        saved_phase=saved_phase,
        saved_remaining=saved_remaining,
        stage=stage,
        stage_until=stage_until,
    )


def release_ambulance_stop(traci, preemption: SignalPreemption) -> None:
    try:
        # Duration zero cancels the matching stop, whether it is still pending
        # on the route or the ambulance has already reached it.
        traci.vehicle.setStop(
            preemption.ambulance_id,
            preemption.incoming_edge,
            preemption.stop_position,
            laneIndex=preemption.incoming_lane,
            duration=0,
            flags=0,
        )
    except Exception as exc:
        print(f"  Note: stop cancellation for {preemption.ambulance_id}: {exc}")


def restore_normal_program(traci, preemption: SignalPreemption, now: float) -> None:
    traci.trafficlight.setProgram(preemption.tls_id, preemption.saved_program)
    traci.trafficlight.setPhase(preemption.tls_id, preemption.saved_phase)
    traci.trafficlight.setPhaseDuration(
        preemption.tls_id, max(1.0, preemption.saved_remaining)
    )
    print(
        f"[{now:7.1f}s] SIGNAL {preemption.tls_id}: normal timed cycle restored "
        f"(program {preemption.saved_program}, phase {preemption.saved_phase})."
    )


def ambulance_has_reached_stop(traci, preemption: SignalPreemption) -> bool:
    vehicle_id = preemption.ambulance_id
    try:
        road_id = traci.vehicle.getRoadID(vehicle_id)
        lane_pos = float(traci.vehicle.getLanePosition(vehicle_id))
        speed = float(traci.vehicle.getSpeed(vehicle_id))
        stopped = bool(traci.vehicle.getStopState(vehicle_id) & 1)
        return (
            road_id == preemption.incoming_edge
            and lane_pos >= preemption.stop_position - 4.0
            and (stopped or speed < 0.3)
        )
    except Exception:
        return False


def ambulance_has_passed(traci, preemption: SignalPreemption, active_ids: set[str]) -> bool:
    vehicle_id = preemption.ambulance_id
    if vehicle_id not in active_ids:
        return True
    try:
        return traci.vehicle.getRoadID(vehicle_id) == preemption.outgoing_edge
    except Exception:
        return False


def update_preemptions(traci, preemptions: dict[str, SignalPreemption], now: float,
                       active_ids: set[str]) -> None:
    for tls_id, item in list(preemptions.items()):
        if item.stage == "yellow_before_preemption" and now >= item.stage_until:
            set_signal_state(traci, tls_id, all_red(len(traci.trafficlight.getRedYellowGreenState(tls_id))))
            item.stage = "all_red_before_preemption"
            item.stage_until = now + ALL_RED_SECONDS
            print(f"[{now:7.1f}s] SIGNAL {tls_id}: all approaches RED for clearance.")

        elif item.stage == "all_red_before_preemption" and now >= item.stage_until:
            # Keep all approaches red until the ambulance is physically at its
            # stop line. This avoids granting a green far ahead of its arrival.
            if ambulance_has_reached_stop(traci, item) or now >= item.stage_until + MAX_PREEMPT_WAIT_SECONDS:
                state = list(all_red(len(traci.trafficlight.getRedYellowGreenState(tls_id))))
                if not 0 <= item.link_index < len(state):
                    raise RuntimeError(f"TLS {tls_id}: invalid emergency link index {item.link_index}")
                state[item.link_index] = "G"
                set_signal_state(traci, tls_id, "".join(state))
                release_ambulance_stop(traci, item)
                item.stage = "ambulance_green"
                item.stage_until = float("inf")
                print(
                    f"[{now:7.1f}s] SIGNAL {tls_id}: GREEN only for {item.ambulance_id} "
                    f"(movement link {item.link_index}); conflicting approaches remain RED."
                )

        elif item.stage == "ambulance_green":
            if ambulance_has_passed(traci, item, active_ids):
                state = list(all_red(len(traci.trafficlight.getRedYellowGreenState(tls_id))))
                state[item.link_index] = "y"
                set_signal_state(traci, tls_id, "".join(state))
                item.stage = "ambulance_yellow"
                item.stage_until = now + POST_EMERGENCY_YELLOW_SECONDS
                print(f"[{now:7.1f}s] SIGNAL {tls_id}: ambulance cleared; its movement turns AMBER.")

        elif item.stage == "ambulance_yellow" and now >= item.stage_until:
            set_signal_state(traci, tls_id, all_red(len(traci.trafficlight.getRedYellowGreenState(tls_id))))
            item.stage = "recovery_all_red"
            item.stage_until = now + ALL_RED_SECONDS
            print(f"[{now:7.1f}s] SIGNAL {tls_id}: post-emergency all-red clearance.")

        elif item.stage == "recovery_all_red" and now >= item.stage_until:
            restore_normal_program(traci, item, now)
            del preemptions[tls_id]


def request_upcoming_preemptions(traci, preemptions: dict[str, SignalPreemption],
                                 now: float, active_ids: set[str]) -> None:
    for ambulance_id in sorted(v for v in active_ids if v.startswith(EMERGENCY_PREFIX)):
        # One signal at a time per ambulance. The next signal is requested
        # after the current pre-emption sequence has restored its normal plan.
        if any(p.ambulance_id == ambulance_id for p in preemptions.values()):
            continue
        try:
            upcoming = traci.vehicle.getNextTLS(ambulance_id)
        except Exception:
            continue
        relevant = [x for x in upcoming if x[0] in TARGET_TLS]
        if not relevant:
            continue
        tls_id, link_index, distance, _state = min(relevant, key=lambda x: x[2])
        if float(distance) > PREEMPTION_TRIGGER_METRES:
            continue
        if tls_id in preemptions:
            continue
        try:
            preemptions[tls_id] = begin_preemption(
                traci, tls_id, ambulance_id, int(link_index), now
            )
        except Exception as exc:
            print(f"[{now:7.1f}s] ERROR: could not request priority at {tls_id}: {exc}")


def main() -> int:
    for required in (CONFIG_FILE, SIGNAL_NETWORK, ROUTE_FILE):
        if not required.is_file():
            print(f"ERROR: Missing {required.name}. Run run.bat from this folder.")
            return 1

    try:
        sumo_home = find_sumo_home()
        os.environ["SUMO_HOME"] = str(sumo_home)
        sys.path.insert(0, str(sumo_home / "tools"))
        import traci  # type: ignore
        import sumolib  # type: ignore
        sumo_binary = sumolib.checkBinary("sumo-gui")
    except Exception as exc:
        print(f"ERROR: Cannot initialise SUMO/TraCI: {exc}")
        return 1

    # SUMO-GUI accepts a comma-separated list of view-settings files.  This
    # opens two windows on the same simulation, each with a TLS phase tracker.
    gui_settings = f"{BASE_DIR / 'osm.view.xml'},{BASE_DIR / 'osm.view2.xml'}"
    command = [
        sumo_binary,
        "-c", str(CONFIG_FILE),
        "--gui-settings-file", gui_settings,
        "--lateral-resolution", "0.2",
        "--device.bluelight.reactiondist", str(REACTION_DISTANCE_METRES),
        "--start",
    ]

    print("Starting signalised emergency-response scenario.")
    print("Traffic: 150 cars, 18 trucks, 2 ambulances.")
    print("Signalised junctions: 312114070 and 312114574.")
    print("Normal traffic: fixed red/amber/green cycle; cars and trucks must stop on red.")
    print("Ambulances: yellow clearance -> all-red -> ambulance-only green -> recovery.")
    print("Blue-light device and sublane rescue-lane response: enabled.")

    connected = False
    preemptions: dict[str, SignalPreemption] = {}
    next_report = 30.0
    try:
        traci.start(command)
        connected = True
        loaded_tls = set(traci.trafficlight.getIDList())
        missing = TARGET_TLS - loaded_tls
        if missing:
            raise RuntimeError(
                f"Signalised network is missing traffic lights {sorted(missing)}. "
                "Re-run run.bat so netconvert rebuilds the network."
            )
        for tls_id in sorted(TARGET_TLS):
            print(
                f"  TLS {tls_id}: {len(traci.trafficlight.getRedYellowGreenState(tls_id))} "
                "signal links; normal signal program active."
            )

        while traci.simulation.getMinExpectedNumber() > 0:
            traci.simulationStep()
            now = float(traci.simulation.getTime())
            active_ids = set(traci.vehicle.getIDList())
            update_preemptions(traci, preemptions, now, active_ids)
            request_upcoming_preemptions(traci, preemptions, now, active_ids)
            if now >= next_report:
                cars = sum(1 for v in active_ids if v.startswith("car_"))
                trucks = sum(1 for v in active_ids if v.startswith("truck_"))
                ambulances = sum(1 for v in active_ids if v.startswith(EMERGENCY_PREFIX))
                signal_states = []
                for tls_id in sorted(TARGET_TLS):
                    try:
                        state = traci.trafficlight.getRedYellowGreenState(tls_id)
                        program = traci.trafficlight.getProgram(tls_id)
                        signal_states.append(f"{tls_id}:{state} [{program}]")
                    except Exception:
                        signal_states.append(f"{tls_id}:unavailable")
                print(
                    f"[{now:7.1f}s] on network: cars={cars:3d}, trucks={trucks:2d}, "
                    f"ambulances={ambulances}; active pre-emptions={len(preemptions)}"
                )
                for signal_state in signal_states:
                    print(f"             SIGNAL {signal_state}")
                next_report += 30.0

        print("\nSimulation completed. Normal signal programs restored.")
        print("Outputs: emergency_tripinfos.xml, emergency_stats.xml, emergency_summary.xml, emergency_mobility.xml")
        input("Press ENTER in this console to close the simulation... ")
        return 0
    except KeyboardInterrupt:
        print("\nSimulation interrupted by user.")
        return 130
    except Exception as exc:
        print(f"\nSUMO/TraCI error: {exc}")
        return 1
    finally:
        if connected:
            try:
                traci.close()
            except Exception:
                pass


if __name__ == "__main__":
    raise SystemExit(main())
