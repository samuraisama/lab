@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Build signalised SUMO network

echo ======================================================
echo  BUILDING TWO REAL TRAFFIC-SIGNAL JUNCTIONS
echo ======================================================
echo.

set "NETCONVERT="
if defined SUMO_HOME if exist "%SUMO_HOME%\bin\netconvert.exe" set "NETCONVERT=%SUMO_HOME%\bin\netconvert.exe"
if not defined NETCONVERT if exist "%ProgramFiles(x86)%\Eclipse\Sumo\bin\netconvert.exe" set "NETCONVERT=%ProgramFiles(x86)%\Eclipse\Sumo\bin\netconvert.exe"
if not defined NETCONVERT if exist "%ProgramFiles%\Eclipse\Sumo\bin\netconvert.exe" set "NETCONVERT=%ProgramFiles%\Eclipse\Sumo\bin\netconvert.exe"
if not defined NETCONVERT if exist "C:\SUMO\bin\netconvert.exe" set "NETCONVERT=C:\SUMO\bin\netconvert.exe"
if not defined NETCONVERT (
    for /f "delims=" %%N in ('where netconvert 2^>nul') do if not defined NETCONVERT set "NETCONVERT=%%N"
)
if not defined NETCONVERT (
    echo ERROR: netconvert.exe was not found.
    echo Set SUMO_HOME to your SUMO 1.28.0 installation folder or add SUMO bin to PATH.
    pause
    exit /b 1
)
if not exist "osm.net.xml.gz" (
    echo ERROR: osm.net.xml.gz is missing from this folder.
    pause
    exit /b 1
)

echo Using: "%NETCONVERT%"
echo Source network: osm.net.xml.gz
echo Signal junctions: 312114070 and 312114574
echo Signal cycle: 90 seconds; amber: 3 seconds; all-red: 1 second
echo.

rem NOTE: Use tls.cycle.time OR tls.green.time, never both.
"%NETCONVERT%" --sumo-net-file "osm.net.xml.gz" --tls.set "312114070,312114574" --tls.default-type static --tls.layout opposites --tls.ungroup-signals --tls.cycle.time 90 --tls.yellow.time 3 --tls.allred.time 1 --output-file "osm.signal.net.xml.gz"
if errorlevel 1 (
    echo.
    echo ERROR: netconvert could not build the signalised network.
    pause
    exit /b 1
)

python verify_signal_network.py
if errorlevel 1 (
    echo.
    echo ERROR: The generated network did not pass traffic-signal validation.
    pause
    exit /b 1
)

echo.
echo Signalised network created successfully: osm.signal.net.xml.gz
echo Both junctions now have red / amber / green programs.
endlocal
exit /b 0
