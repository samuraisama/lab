@echo off
REM Original launcher preserved from the uploaded project.
sumo-gui -c osm.sumocfg
