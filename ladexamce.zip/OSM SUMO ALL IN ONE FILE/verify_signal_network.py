#!/usr/bin/env python3
"""Verify that netconvert created both requested traffic-light controllers."""
from __future__ import annotations
import gzip
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

BASE = Path(__file__).resolve().parent
NETWORK = BASE / "osm.signal.net.xml.gz"
TARGETS = {"312114070", "312114574"}


def main() -> int:
    if not NETWORK.is_file():
        raise FileNotFoundError("osm.signal.net.xml.gz was not generated")
    with gzip.open(NETWORK, "rb") as stream:
        root = ET.parse(stream).getroot()

    junctions = {j.get("id"): j for j in root.findall("junction")}
    logics = {}
    for logic in root.findall("tlLogic"):
        logics.setdefault(logic.get("id"), []).append(logic)

    errors = []
    for tls_id in sorted(TARGETS):
        junction = junctions.get(tls_id)
        if junction is None:
            errors.append(f"junction {tls_id} is missing")
        elif junction.get("type") != "traffic_light":
            errors.append(f"junction {tls_id} has type={junction.get('type')!r}, not traffic_light")
        if tls_id not in logics:
            errors.append(f"traffic-light program {tls_id} is missing")
            continue
        for logic in logics[tls_id]:
            phases = logic.findall("phase")
            if len(phases) < 2:
                errors.append(f"traffic-light {tls_id} has fewer than two phases")
                continue
            state_lengths = {len(p.get("state", "")) for p in phases}
            if len(state_lengths) != 1:
                errors.append(f"traffic-light {tls_id} has inconsistent phase-state lengths")
            chars = "".join(p.get("state", "") for p in phases)
            if (not any(c in "Gg" for c in chars)
                    or not any(c in "rR" for c in chars)
                    or not any(c in "yY" for c in chars)):
                errors.append(f"traffic-light {tls_id} does not have green, red and amber states")

        controlled = [c for c in root.findall("connection") if c.get("tl") == tls_id]
        if not controlled:
            errors.append(f"traffic-light {tls_id} controls no connections")

    if errors:
        for error in errors:
            print("ERROR:", error)
        return 1

    for tls_id in sorted(TARGETS):
        phase_count = sum(len(x.findall("phase")) for x in logics[tls_id])
        link_count = sum(1 for c in root.findall("connection") if c.get("tl") == tls_id)
        print(f"PASS: {tls_id} | traffic_light | {phase_count} phases | {link_count} controlled movements")
    print("Signal-network validation passed.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
