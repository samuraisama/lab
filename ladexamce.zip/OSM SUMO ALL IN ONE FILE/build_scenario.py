#!/usr/bin/env python3
"""Generate three-class traffic with mandatory flows through two signalised nodes."""
from __future__ import annotations
import gzip
import math
import random
import sys
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
NETWORK = HERE / "osm.net.xml.gz"
PASSENGER_SOURCE = HERE / "q2.passenger.rou.xml"
TRUCK_SOURCE = HERE / "q2.truck.rou.xml"
EMERGENCY_SOURCE = HERE / "q2.emergency.rou.xml"
OUTPUT = HERE / "emergency.rou.xml"

SIGNAL_JUNCTIONS = ("312114070", "312114574")
PASSENGER_COUNT = 150
TRUCK_COUNT = 18
AMBULANCE_DEPARTURES = (180.0, 420.0)
DEMAND_END = 600.0
RANDOM_SEED = 20261124
LANE_CHANGE_BUFFER_METRES = 40.0


def parse_xml(path: Path) -> ET.Element:
    if not path.is_file():
        raise FileNotFoundError(f"Required file is missing: {path.name}")
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rb") as stream:
        return ET.parse(stream).getroot()


def read_network():
    root = parse_xml(NETWORK)
    edge_info = {}
    for edge in root.findall("edge"):
        if edge.get("function") == "internal":
            continue
        lanes = edge.findall("lane")
        if not lanes:
            continue
        edge_info[edge.get("id")] = {
            "length": max(float(lane.get("length", "0")) for lane in lanes),
            "lane_count": len(lanes),
            "lane_indices": set(range(len(lanes))),
            "from": edge.get("from"),
            "to": edge.get("to"),
        }
    connections = defaultdict(set)
    for con in root.findall("connection"):
        if con.get("from") and con.get("to"):
            connections[(con.get("from"), con.get("to"))].add(int(con.get("fromLane", "0")))
    if not edge_info or not connections:
        raise RuntimeError("Could not read usable edges/connections from osm.net.xml.gz")
    missing = [node for node in SIGNAL_JUNCTIONS if not any(x.get("id") == node for x in root.findall("junction"))]
    if missing:
        raise RuntimeError(f"Signal junctions are missing from the supplied network: {missing}")
    return edge_info, connections


def route_junctions(path_edges, edge_info):
    result = set()
    for first, second in zip(path_edges, path_edges[1:]):
        if first in edge_info and second in edge_info:
            node = edge_info[first]["to"]
            if node == edge_info[second]["from"]:
                result.add(node)
    return result


def route_is_lane_feasible(edges, edge_info, connections):
    if len(edges) < 2:
        return False, "route has fewer than two edges"
    for edge_id in edges:
        if edge_id not in edge_info:
            return False, f"unknown edge {edge_id}"
    for from_edge, to_edge in zip(edges, edges[1:]):
        permitted = connections.get((from_edge, to_edge), set())
        if not permitted:
            return False, f"no network connection {from_edge} -> {to_edge}"
        info = edge_info[from_edge]
        all_lanes = info["lane_indices"]
        if len(all_lanes) > 1 and permitted != all_lanes and info["length"] < LANE_CHANGE_BUFFER_METRES:
            return False, f"lane-restricted turn {from_edge} -> {to_edge} on {info['length']:.2f} m edge"
    return True, ""


def load_candidates(path: Path, edge_info, connections, min_length, max_length):
    root = parse_xml(path)
    unique = {}
    rejected = Counter()
    for vehicle in root.findall("vehicle"):
        route = vehicle.find("route")
        if route is None:
            rejected["missing route"] += 1
            continue
        edges = route.get("edges", "").split()
        if not edges or any(e not in edge_info for e in edges):
            rejected["empty or unknown edge"] += 1
            continue
        length = sum(edge_info[e]["length"] for e in edges)
        if not min_length <= length <= max_length:
            rejected["outside useful trip length"] += 1
            continue
        feasible, reason = route_is_lane_feasible(edges, edge_info, connections)
        if not feasible:
            rejected[reason.split(" on ")[0]] += 1
            continue
        key = tuple(edges)
        if key not in unique:
            unique[key] = {
                "edges": edges,
                "length": length,
                "junctions": route_junctions(edges, edge_info),
                "source_id": vehicle.get("id", ""),
            }
    return list(unique.values()), rejected


def spread_departures(count, start, end, rng, jitter):
    if count <= 0:
        return []
    if count == 1:
        return [(start + end) / 2]
    values = []
    for i in range(count):
        base = start + (end - start) * i / (count - 1)
        values.append(min(end, max(start, base + rng.uniform(-jitter, jitter))))
    return sorted(values)


def choose_targeted_routes(candidates, count, targets, rng):
    """Reserve a predictable number of vehicles for each signal, then fill remainder."""
    selected = []
    selected_keys = set()
    for junction_id, wanted in targets:
        pool = [c for c in candidates if junction_id in c["junctions"] and tuple(c["edges"]) not in selected_keys]
        if len(pool) < wanted:
            raise RuntimeError(
                f"Only {len(pool)} unique feasible routes pass signal {junction_id}; {wanted} required."
            )
        chosen = rng.sample(pool, wanted)
        selected.extend(chosen)
        selected_keys.update(tuple(c["edges"]) for c in chosen)
    if len(selected) > count:
        raise RuntimeError("Signal route allocations exceed total vehicle count")
    remainder = [c for c in candidates if tuple(c["edges"]) not in selected_keys]
    if len(remainder) < count - len(selected):
        raise RuntimeError("Not enough unique routes to complete traffic demand")
    selected.extend(rng.sample(remainder, count - len(selected)))
    rng.shuffle(selected)
    return selected


def route_usage(routes):
    usage = Counter()
    for route in routes:
        usage.update(set(route["edges"]))
    return usage


def choose_ambulance_routes(candidates, traffic_routes, count):
    both = [c for c in candidates if all(j in c["junctions"] for j in SIGNAL_JUNCTIONS)]
    if len(both) < count:
        raise RuntimeError(
            f"Only {len(both)} lane-feasible emergency routes pass BOTH signalised junctions; {count} required."
        )
    usage = route_usage(traffic_routes)
    def score(route):
        return sum(
            traffic_weight(edge, usage) * math.log1p(usage.get(edge, 0))
            for edge in set(route["edges"])
        )
    ranked = sorted(both, key=score, reverse=True)
    chosen = []
    for candidate in ranked:
        if chosen:
            a, b = set(chosen[0]["edges"]), set(candidate["edges"])
            similarity = len(a & b) / max(1, len(a | b))
            if similarity > 0.90:
                continue
        chosen.append(candidate)
        if len(chosen) == count:
            break
    if len(chosen) < count:
        for candidate in ranked:
            if candidate not in chosen:
                chosen.append(candidate)
            if len(chosen) == count:
                break
    return chosen


def traffic_weight(edge, usage):
    return 1.0 + min(usage.get(edge, 0), 10) * 0.2


def add_vtype(root, attrs, params=()):
    vtype = ET.SubElement(root, "vType", attrs)
    for key, value in params:
        ET.SubElement(vtype, "param", {"key": key, "value": value})


def make_vehicle(vehicle_id, vehicle_type, depart, route):
    vehicle = ET.Element("vehicle", {
        "id": vehicle_id,
        "type": vehicle_type,
        "depart": f"{depart:.2f}",
        "departLane": "best",
        "departSpeed": "0",
    })
    ET.SubElement(vehicle, "route", {"edges": " ".join(route["edges"])})
    return vehicle


def main():
    rng = random.Random(RANDOM_SEED)
    edge_info, connections = read_network()
    passenger, _ = load_candidates(PASSENGER_SOURCE, edge_info, connections, 300, 3200)
    truck, _ = load_candidates(TRUCK_SOURCE, edge_info, connections, 250, 3200)
    emergency, _ = load_candidates(EMERGENCY_SOURCE, edge_info, connections, 450, 3600)

    # 100 cars are deliberately routed through the primary signal and 25
    # additional cars through the secondary signal. 10 trucks use the first
    # signal and 4 use the second. Remaining traffic provides background demand.
    passenger_routes = choose_targeted_routes(
        passenger, PASSENGER_COUNT,
        [(SIGNAL_JUNCTIONS[0], 100), (SIGNAL_JUNCTIONS[1], 25)], rng
    )
    truck_routes = choose_targeted_routes(
        truck, TRUCK_COUNT,
        [(SIGNAL_JUNCTIONS[0], 10), (SIGNAL_JUNCTIONS[1], 4)], rng
    )
    ambulance_routes = choose_ambulance_routes(
        emergency, passenger_routes + truck_routes, len(AMBULANCE_DEPARTURES)
    )

    root = ET.Element("routes", {
        "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
        "xsi:noNamespaceSchemaLocation": "http://sumo.dlr.de/xsd/routes_file.xsd",
    })
    root.append(ET.Comment(
        " Synthetic 15-minute urban demonstration demand for the supplied Mysuru OSM network. "
        "Not measured traffic counts. Cars and trucks are deliberately routed through two signalised junctions. "
    ))

    add_vtype(root, {
        "id": "passenger_car", "vClass": "passenger", "guiShape": "passenger", "color": "0,120,255",
        "accel": "2.6", "decel": "4.5", "emergencyDecel": "8.0", "sigma": "0.35", "tau": "1.2",
        "length": "4.6", "width": "1.8", "minGap": "2.5", "maxSpeed": "40.0", "speedFactor": "1.0", "speedDev": "0.05",
    }, [("device.bluelight.reaction-prob-near", "0.90"), ("device.bluelight.reaction-prob-far", "0.55"), ("device.bluelight.near-dist", "35")])

    add_vtype(root, {
        "id": "urban_truck", "vClass": "truck", "guiShape": "truck", "color": "255,165,0",
        "accel": "1.0", "decel": "3.2", "emergencyDecel": "6.0", "sigma": "0.25", "tau": "1.8",
        "length": "10.5", "width": "2.5", "minGap": "3.0", "maxSpeed": "25.0", "speedFactor": "0.80", "speedDev": "0.04",
    }, [("device.bluelight.reaction-prob-near", "0.90"), ("device.bluelight.reaction-prob-far", "0.55"), ("device.bluelight.near-dist", "35")])

    add_vtype(root, {
        "id": "ambulance", "vClass": "emergency", "guiShape": "emergency", "color": "255,255,255",
        "accel": "3.0", "decel": "6.0", "emergencyDecel": "10.0", "sigma": "0.10", "tau": "0.7",
        "length": "5.4", "width": "2.0", "minGap": "2.0", "maxSpeed": "40.0", "speedFactor": "1.15", "speedDev": "0.02",
    }, [("has.bluelight.device", "true"), ("device.bluelight.reactiondist", "60")])

    passenger_times = spread_departures(PASSENGER_COUNT, 2, 580, rng, 0.5)
    truck_times = spread_departures(TRUCK_COUNT, 12, 570, rng, 2.0)
    vehicles = []
    for i, (depart, route) in enumerate(zip(passenger_times, passenger_routes), 1):
        vehicles.append((depart, make_vehicle(f"car_{i:03d}", "passenger_car", depart, route)))
    for i, (depart, route) in enumerate(zip(truck_times, truck_routes), 1):
        vehicles.append((depart, make_vehicle(f"truck_{i:03d}", "urban_truck", depart, route)))
    for i, (depart, route) in enumerate(zip(AMBULANCE_DEPARTURES, ambulance_routes), 1):
        vehicles.append((depart, make_vehicle(f"ambulance_{i:02d}", "ambulance", depart, route)))

    for _, vehicle in sorted(vehicles, key=lambda item: (item[0], item[1].get("id", ""))):
        root.append(vehicle)

    if hasattr(ET, "indent"):
        ET.indent(root, space="    ")
    ET.ElementTree(root).write(OUTPUT, encoding="UTF-8", xml_declaration=True)

    print(f"Created {OUTPUT.name}")
    print(f"  passenger cars: {PASSENGER_COUNT}")
    print(f"  trucks:         {TRUCK_COUNT}")
    print(f"  ambulances:     {len(AMBULANCE_DEPARTURES)} at {list(AMBULANCE_DEPARTURES)} s")
    print(f"  total vehicles: {len(vehicles)}")
    print("  minimum routed flows: cars 100 through primary signal, 25 through secondary; trucks 10 and 4 respectively")
    print("  both ambulances pass both signalised junctions")
    print("  departures sorted; lane-connectivity preflight applied")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
