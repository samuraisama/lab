@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title SUMO - Real World Signalised Emergency Priority

echo ================================================================
echo  REAL-WORLD TRAFFIC SIGNALS + AMBULANCE PRE-EMPTION
echo ================================================================
echo.
echo STEP 1/3 - Building signalised road network...
call build_signal_network.bat
if errorlevel 1 (
    echo.
    echo Network build failed. See the error above.
    pause
    exit /b 1
)

echo.
echo STEP 2/3 - Validating route and signal demand...
python validate_scenario.py
if errorlevel 1 (
    echo.
    echo Pre-flight failed. The simulation was not started.
    pause
    exit /b 1
)

echo.
echo STEP 3/3 - Starting SUMO-GUI and signal controller...
echo Cars and trucks obey red lights and stop at the stop line.
echo Ambulance calls pre-emption: amber, all-red, ambulance-only green,
echo ambulance amber, all-red, then normal signal cycle resumes.
echo Two map views will open, one for each signalised junction.
echo.
python run_emergency_scenario.py
set RESULT=%ERRORLEVEL%
if not "%RESULT%"=="0" (
    echo.
    echo Simulation/controller exited with code %RESULT%.
    pause
)
endlocal
exit /b %RESULT%
