SUMO REAL-WORLD-STYLE SIGNALISED EMERGENCY RESPONSE
==================================================

PROJECT BASIS
-------------
VERSION 4 FIX
-------------
The netconvert command uses --tls.cycle.time 90 and deliberately omits
--tls.green.time. SUMO rejects those two mutually exclusive options when
supplied together.

This project is based on the supplied Mysuru OpenStreetMap network in
osm.net.xml.gz. The original network had no traffic-light controllers at the
selected junctions. This project deliberately converts two existing four-arm
junctions into signalised intersections so the emergency-response scenario can
be demonstrated in SUMO.

Important distinction: the road layout comes from the supplied OSM map, but the
two traffic signals, their timing plan, vehicle demand and emergency dispatches
are a simulation scenario. They are not claimed to be measured live traffic
counts or verified existing signal timings in Mysuru.

THE THREE VEHICLE CLASSES
-------------------------
1. Passenger cars: 150 vehicles. Normal urban driving, car dimensions,
   acceleration, speed limits and car-following behaviour.
2. Trucks: 18 vehicles. Longer and wider bodies, slower acceleration, lower
   maximum speed and larger following gaps.
3. Ambulances: 2 vehicles. Emergency vehicle class, blue-light device, higher
   speed factor, emergency overtaking behaviour and priority at both signals.

Traffic is generated over approximately the first 10 minutes. Ambulance 1 is
scheduled at 180 seconds and ambulance 2 at 420 seconds. The simulation runs
for 900 seconds so vehicles can finish their routes.

THE TWO SIGNALISED JUNCTIONS
----------------------------
The following existing four-arm junctions are signalised:

  312114070  Primary signal junction
  312114574  Secondary signal junction

The generated route demand is deliberately concentrated through these
junctions so the signals are visible and tested by all three vehicle classes.
Current route-file counts after generation:

  Junction 312114070: 112 cars, 11 trucks, 2 ambulances
  Junction 312114574:  27 cars,  6 trucks, 2 ambulances

The actual route files are generated from feasible paths in the supplied
network. Disconnected turns and short lane-restricted approaches are rejected.
Vehicles are sorted by departure time.

NORMAL SIGNAL OPERATION
-----------------------
The two nodes are converted into static traffic-light controllers by
netconvert. SUMO creates the signal phases using the configured 90-second cycle,
yellow and all-red timing parameters. Green durations are allocated by netconvert. Cars and trucks use the ordinary SUMO
traffic-light rules: they slow down and stop at red, proceed on green, and
respond to yellow according to their braking ability and distance to the stop
line.

AMBULANCE PRE-EMPTION
--------------------
When an ambulance is within 120 metres of one of the two signalised junctions,
the TraCI controller:

  1. Identifies the exact signal link matching the ambulance's next route turn.
  2. Places a temporary stop for the ambulance before the stop line so it does
     not enter while the conflicting phase is clearing.
  3. Changes currently green approaches to amber for 3 seconds.
  4. Holds all signal links red for at least 1.5 seconds and waits for the
     ambulance to reach the stop position (with a 30-second fail-safe).
  5. Gives green only to the ambulance's exact movement; all conflicting
     signal links remain red.
  6. After the ambulance exits the junction, gives its movement amber for
     3 seconds, then an all-red clearance for 1.5 seconds.
  7. Restores the normal static signal program and its interrupted phase.

The blue-light device and the SUMO sublane model are also enabled. They provide
flashing blue-light visualisation and make surrounding vehicles form a virtual
rescue lane. The controller does not disable general junction safety checks
with a speed-mode override.

WHAT YOU MUST RUN
-----------------
Run ONLY:

  run.bat

Do not start osm.sumocfg directly for the emergency-pre-emption demonstration.
The .sumocfg file defines the simulation inputs; run.bat additionally builds
the signalised network and launches the TraCI controller that changes the
signals for approaching ambulances.

RUN SEQUENCE
------------
1. Extract the complete project folder.
2. Keep all files in the same folder, especially osm.net.xml.gz, q2.*.rou.xml,
   osm.poly.xml.gz, the Python scripts and the batch files.
3. Ensure SUMO 1.28.0 is installed and SUMO_HOME points to the SUMO installation
   directory (the directory containing bin and tools). netconvert.exe must be
   available in SUMO_HOME\bin or on PATH.
4. Ensure Python 3 is installed and the command `python` works in Command Prompt.
5. Double-click run.bat.

run.bat performs these steps automatically:
  STEP 1: build_signal_network.bat creates osm.signal.net.xml.gz from the
          original road network and adds traffic lights at the two nodes.
  STEP 2: validate_scenario.py checks the generated signal network, route
          connectivity, vehicle counts, junction demand and departure order.
  STEP 3: run_emergency_scenario.py launches SUMO-GUI and controls ambulance
          signal pre-emption through TraCI.

Two SUMO-GUI views open: one centred on each signalised junction. Each view
includes a traffic-light phase tracker.

OUTPUT FILES
------------
The simulation writes:
  emergency_tripinfos.xml
  emergency_stats.xml
  emergency_summary.xml
  emergency_mobility.xml

TROUBLESHOOTING
---------------
- If run.bat says netconvert.exe is missing, set SUMO_HOME to the SUMO 1.28.0
  installation folder or add SUMO_HOME\bin to PATH.
- If Python cannot import traci or sumolib, check that SUMO_HOME points to the
  correct installation; the script imports these modules from SUMO_HOME\tools.
- If the route/signal pre-flight fails, do not bypass it. Keep the error text
  and inspect the named edge, node or vehicle.
- The generated signalised network is named osm.signal.net.xml.gz. The original
  osm.net.xml.gz is retained unchanged and can still be used separately.

FILES OF INTEREST
-----------------
build_signal_network.bat       Adds the two traffic-light controllers.
verify_signal_network.py       Verifies both controllers and their phases.
build_scenario.py              Rebuilds 150 cars, 18 trucks and 2 ambulances.
emergency.rou.xml              Ready-to-run vehicle types, routes and demand.
validate_scenario.py           Checks network, route and traffic-light demand.
run_emergency_scenario.py      Runs TraCI ambulance pre-emption.
osm.sumocfg                    Loads the signalised network and output files.
osm.view.xml                   GUI view of the primary junction and tracker.
osm.view2.xml                  GUI view of the secondary junction and tracker.

The project files have been structurally checked and the route file has been
validated against the supplied base network. The final netconvert build and
SUMO-GUI execution must run on the user's Windows installation; those Windows
binaries are not available in the file-generation environment.
